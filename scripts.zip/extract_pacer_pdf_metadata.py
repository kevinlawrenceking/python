import sys
import argparse
import pyodbc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
import traceback
from bs4 import BeautifulSoup
import re
import uuid

from scraper_base import log_message, setup_logging, get_db_cursor, get_task_context_by_tool_id

CHROMEDRIVER_PATH = "C:/WebDriver/chromedriver.exe"
LOG_FILE = r"u:/tmztools/python/logs/download_pacer_pdf_visible.log"
setup_logging(LOG_FILE)

def extract_doc_rows(soup):
    return [tr for tr in soup.find_all("tr") if tr.find("a", href=re.compile("doc1")) and 'document_' in str(tr)]

def parse_doc_row(tr, base_url, pdf_type, default_pdf_title):
    tds = tr.find_all("td")
    try:
        a_tag = tr.find("a", href=re.compile(r'doc1'))
        if not a_tag:
            return None

        pdf_url = a_tag['href']
        if not pdf_url.startswith("http"):
            pdf_url = base_url + pdf_url

        match = re.search(r'/doc1/(\d+)', pdf_url)
        pacer_doc_id = int(match.group(1)) if match else None

        pdf_no = int(a_tag.text.strip()) if a_tag.text.strip().isdigit() else 0
        desc = default_pdf_title if pdf_type == "Docket" else " ".join(td.get_text(strip=True) for td in tds[2:4])

        new_filename = f"{pacer_doc_id}.pdf" if pacer_doc_id else ""

        return {
            "id": str(uuid.uuid4()),
            "pacer_doc_id": pacer_doc_id,
            "pdf_url": pdf_url,
            "pdf_title": desc,
            "pdf_type": pdf_type,
            "pdf_no": pdf_no,
            "local_pdf_filename": new_filename
        }
    except Exception as e:
        return None

def main():
    parser = argparse.ArgumentParser(description="Scrape and insert PACER PDF metadata only.")
    parser.add_argument("case_event_id", type=str, help="GUID of the case_events record")
    args = parser.parse_args()

    try:
        script_filename = os.path.splitext(os.path.basename(__file__))[0]
        setup_logging(f"u:/tmztools/python/logs/{script_filename}.log")

        conn, cursor = get_db_cursor()
        context = get_task_context_by_tool_id(cursor, 2)
        fk_task_run = context["fk_task_run"] if context else None

        cursor.execute("""
            UPDATE docketwatch.dbo.case_events
            SET arr_de_seq_nums = 
                SUBSTRING(event_url, CHARINDEX('de_seq_num=', event_url) + 11, 
                        CHARINDEX('&', event_url + '&', CHARINDEX('de_seq_num=', event_url)) 
                        - CHARINDEX('de_seq_num=', event_url) - 11)
            WHERE event_url IS NOT NULL
            AND arr_de_seq_nums IS NULL
            AND event_url LIKE '%de_seq_num%'
        """)
        conn.commit()

        cursor.execute("SELECT username, pass, login_url FROM dbo.tools WHERE id = 2")
        row = cursor.fetchone()
        if not row:
            log_message(cursor, fk_task_run, "ERROR", "PACER credentials not found in DB (tools.id=2).")
            sys.exit()
        USERNAME, PASSWORD, LOGIN_URL = row

        cursor.execute("""
            SELECT c.pacer_id as case_id,
                   LEFT(e.event_url, CHARINDEX('.gov', e.event_url) + 3) AS base_url,
                   e.event_description,
                   e.event_url
            FROM docketwatch.dbo.case_events e
            INNER JOIN docketwatch.dbo.cases c on c.id = e.fk_cases
            WHERE e.id = ?
        """, (args.case_event_id,))
        row = cursor.fetchone()
        if not row:
            log_message(cursor, fk_task_run, "INFO", "No event data found for case_event_id.")
            sys.exit()

        case_id, base_url, event_description, event_url = row

        opts = Options()
        opts.add_argument("--headless=new")  
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        service = Service(CHROMEDRIVER_PATH)
        driver = webdriver.Chrome(service=service, options=opts)
        wait = WebDriverWait(driver, 15)

        driver.get(LOGIN_URL)
        wait.until(EC.presence_of_element_located((By.NAME, "loginForm:loginName"))).send_keys(USERNAME)
        driver.find_element(By.NAME, "loginForm:password").send_keys(PASSWORD)
        try:
            driver.find_element(By.NAME, "loginForm:clientCode").send_keys("DocketWatch")
        except:
            pass
        driver.find_element(By.NAME, "loginForm:fbtnLogin").click()
        time.sleep(3)

        driver.get(event_url)
        time.sleep(2)

        if "referrer_form" in driver.page_source:
            log_message(cursor, fk_task_run, "INFO", "PACER CSRF warning detected. Submitting form.")
            try:
                form = driver.find_element(By.ID, "referrer_form")
                driver.execute_script("arguments[0].submit();", form)
                time.sleep(3)
            except Exception as e:
                log_message(cursor, fk_task_run, "ERROR", f"Failed to submit referrer_form: {str(e)}")

        soup = BeautifulSoup(driver.page_source, "html.parser")
        doc_rows = extract_doc_rows(soup)

        if not doc_rows:
            match = re.search(r'/doc1/(\d+)', event_url)
            if match:
                pacer_doc_id = int(match.group(1))
                cursor.execute("SELECT COUNT(*) FROM docketwatch.dbo.case_events_pdf WHERE pacer_doc_id = ?", (pacer_doc_id,))
                exists = cursor.fetchone()[0] > 0
                if not exists:
                    new_filename = f"{pacer_doc_id}.pdf"
                    cursor.execute("""
                        INSERT INTO docketwatch.dbo.case_events_pdf
                        (id, fk_case_event, pacer_doc_id, pdf_url, pdf_title, pdf_type, pdf_no, isDownloaded, local_pdf_filename, created_at)
                        VALUES (?, ?, ?, ?, ?, 'Docket', 0, 0, ?, GETDATE())
                    """, (
                        str(uuid.uuid4()), args.case_event_id, pacer_doc_id, event_url, event_description, new_filename
                    ))
                    conn.commit()
                    log_message(cursor, fk_task_run, "INFO", f"Inserted fallback single docket PDF {pacer_doc_id}.")
            else:
                log_message(cursor, fk_task_run, "INFO", "No valid document rows or fallback docket match found.")
        else:
            for i, tr in enumerate(doc_rows):
                pdf_type = "Docket" if i == 0 else "Attachment"
                doc_data = parse_doc_row(tr, base_url, pdf_type, event_description)
                if not doc_data:
                    continue
                cursor.execute("SELECT COUNT(*) FROM docketwatch.dbo.case_events_pdf WHERE pacer_doc_id = ?", (doc_data["pacer_doc_id"],))
                exists = cursor.fetchone()[0] > 0
                if not exists:
                    cursor.execute("""
                        INSERT INTO docketwatch.dbo.case_events_pdf
                        (id, fk_case_event, pacer_doc_id, pdf_url, pdf_title, pdf_type, pdf_no, isDownloaded, local_pdf_filename, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, GETDATE())
                    """, (
                        doc_data["id"], args.case_event_id, doc_data["pacer_doc_id"], doc_data["pdf_url"],
                        doc_data["pdf_title"], doc_data["pdf_type"], doc_data["pdf_no"], doc_data["local_pdf_filename"]
                    ))
            conn.commit()
            log_message(cursor, fk_task_run, "INFO", f"Inserted metadata for {len(doc_rows)} PDFs.")

    except Exception as e:
        log_message(cursor, fk_task_run, "ERROR", f"An error occurred: {str(e)}")
        traceback.print_exc()
    finally:
        if 'driver' in locals() and driver:
            driver.quit()
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    main()
