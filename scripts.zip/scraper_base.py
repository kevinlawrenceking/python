# scraper_base.py
# Shared logic for all DocketWatch scraper scripts

import os
import sys
import re
import time
import logging
import pyodbc
import requests
from bs4 import BeautifulSoup
import random
import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# === Email/Logging Setup ===
FROM_EMAIL = "it@tmz.com"
ALERT_EMAILS = [
    "kevin.king@tmz.com"
]
SMTP_SERVER = "mx0a-00195501.pphosted.com"
SMTP_PORT = 25

def setup_logging(log_path):
    logging.basicConfig(filename=log_path, level=logging.INFO,
                        format="%(asctime)s - %(levelname)s - %(message)s")

# Initialize script filename and logging
DEFAULT_CHROMEDRIVER_PATH = "C:/WebDriver/chromedriver.exe"
def init_logging_and_filename():
    script_filename = os.path.splitext(os.path.basename(__file__))[0]
    log_path = rf"\\10.146.176.84\general\tmztools\python\logs\{script_filename}.log"
    setup_logging(log_path)
    logging.info(f"=== Script {script_filename} started ===")
    return script_filename

# Open database connection
def get_db_cursor():
    conn = pyodbc.connect("DSN=Docketwatch;TrustServerCertificate=yes;")
    conn.setdecoding(pyodbc.SQL_WCHAR, encoding='utf-8')
    conn.setencoding(encoding='utf-8')
    return conn, conn.cursor()

def log_message(cursor, fk_task_run, log_type, message, fk_case=None):
    logging.info(message)
    if not cursor or not fk_task_run:
        return None
    try:
        cursor.execute("""
            INSERT INTO docketwatch.dbo.task_runs_log (
                fk_task_run, log_timestamp, log_type, description, fk_case
            )
            OUTPUT INSERTED.id 
            VALUES (?, GETDATE(), ?, ?, ?)
        """, (fk_task_run, log_type, message, fk_case))
        log_id = cursor.fetchone()[0]
        cursor.connection.commit()
        return log_id
    except Exception as ex:
        logging.warning(f"Failed to write to task_runs_log: {ex}")
        return None

# === Not Found Case Alerting ===
def send_not_found_email(case_id, fail_count, level, last_checked=None):
    subject = f"DocketWatch {level}: Case ID {case_id} Not Found"
    body = f"""
    <html>
    <body>
        <p>Case ID <strong>{case_id}</strong> was not found.</p>
        <p>Failure Count: {fail_count}</p>
        {"<p>Last Checked: " + str(last_checked) + "</p>" if last_checked else ""}
    </body>
    </html>
    """
    msg = MIMEMultipart("alternative")
    msg["From"] = FROM_EMAIL
    msg["To"] = ", ".join(ALERT_EMAILS)
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "html"))

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.sendmail(FROM_EMAIL, ALERT_EMAILS, msg.as_string())
    except Exception as e:
        logging.error(f"Failed to send not-found email for case {case_id}: {e}")

def mark_case_not_found(cursor, case_id, fk_task_run=None, threshold=3):
    """
    Increments the not_found_count and sets not_found_flag when threshold is hit.
    Also updates last_not_found timestamp. Sends an email to kevin.king@tmz.com.
    Logs an alert if threshold reached, otherwise logs a warning.

    Args:
        cursor: pyodbc cursor object
        case_id: The ID of the case to flag
        fk_task_run: Optional. Used for logging.
        threshold: How many failures before flag is set (default 3)
    """
    cursor.execute("""
        UPDATE docketwatch.dbo.cases
        SET 
            not_found_count = ISNULL(not_found_count, 0) + 1,
            last_not_found = GETDATE(),
            not_found_flag = CASE 
                                WHEN ISNULL(not_found_count, 0) + 1 >= ? THEN 1
                                ELSE 0
                             END
        WHERE id = ?
    """, (threshold, case_id))
    cursor.connection.commit()

    # Check if threshold reached for alerting
    cursor.execute("SELECT not_found_count, last_not_found FROM docketwatch.dbo.cases WHERE id = ?", (case_id,))
    row = cursor.fetchone()
    count = row[0]
    last_checked = row[1]

    if count >= threshold:
        level = "ALERT"
        log_message(cursor, fk_task_run, "ALERT", f"Case ID {case_id} could not be found {count} times and is now flagged as not found.", fk_case=case_id)
        send_not_found_email(case_id, count, level, last_checked)
    else:
        level = "WARNING"
        log_message(cursor, fk_task_run, "WARNING", f"Case ID {case_id} was not found (failure count: {count}).", fk_case=case_id)

# === Tool/Task/Selectors Utilities ===

def get_task_context_by_tool_id(cursor, tool_id):
    cursor.execute("""
        SELECT TOP 1 
            r.id, 
            t.id as tool_id, 
            t.search_url, 
            t.isLogin, 
            t.login_url,
            t.username, 
            t.pass, 
            s.filename, 
            s.filename + '.log' as logfile_name,
            t.username_selector,
            t.password_selector,
            t.search_button_selector,
            t.login_checkbox,
            t.login_button_selector 
        FROM docketwatch.dbo.tools t
        LEFT JOIN docketwatch.dbo.scheduled_task s ON s.fk_tool = t.id
        LEFT JOIN docketwatch.dbo.task_runs r ON r.fk_scheduled_task = s.id
        WHERE t.id = ?
        ORDER BY r.id DESC
    """, (tool_id,))

    row = cursor.fetchone()
    return {
        "fk_task_run": row[0] if row else None,
        "tool_id": row[1] if row else None,
        "search_url": row[2] if row else None,
        "is_login": bool(row[3]) if row else False,
        "login_url": row[4] if row else None,
        "username": row[5] if row else None,
        "pass": row[6] if row else None,
        "filename": row[7] if row else None,
        "logfile_name": row[8] if row else "docketwatch_scraper.log",
        "username_selector": row[9] if row else None,
        "password_selector": row[10] if row else None,
        "search_button_selector": row[11] if row else None,
        "login_checkbox": row[12] if row else None,
        "login_button_selector": row[13] if row else None
    } if row else None

def mark_case_found(cursor, case_id):
    """
    Resets not_found_count, not_found_flag, last_not_found when a previously not found case is now found.
    Updates last_found to current timestamp.
    """
    cursor.execute("""
        UPDATE docketwatch.dbo.cases
        SET
            not_found_count = 0,
            not_found_flag = 0,
            last_not_found = NULL,
            last_found = GETDATE()
        WHERE id = ?
    """, (case_id,))
    cursor.connection.commit()

def update_case_records(cursor, case_id, case_number, case_name, TOOL_ID, fk_court, case_type, fk_task_run, current_url):
    # Update master case record
    cursor.execute("""
        UPDATE docketwatch.dbo.cases
        SET
            case_number = ?,
            case_name = ?,
            fk_tool = ?,
            status = 'Tracked',
            fk_court = ?,
            case_type = ?,
            fk_task_run_log = ?,
            last_updated = GETDATE()
        WHERE id = ?
    """, (case_number, case_name, TOOL_ID, fk_court, case_type, fk_task_run, case_id))
    # Update tool-specific case record
    cursor.execute("""
        UPDATE docketwatch.dbo.cases
        SET
            fk_tool = ?,
            case_number = ?,
            case_name = ?,
            case_url = ?,
            is_tracked = 1,
            last_updated = GETDATE(),
            fk_task_run_log = ?
        WHERE id = ?
    """, (TOOL_ID, case_number, case_name, current_url, fk_task_run, case_id))
    cursor.connection.commit()
    log_message(cursor, fk_task_run, "INFO", f"Updated case {case_number} ({case_name}).", fk_case=case_id)

def insert_new_case_events(cursor, fk_case, events, fk_task_run):
    inserted = 0
    for event_date, description, extra in events:
        cursor.execute("""
            SELECT COUNT(*) FROM docketwatch.dbo.case_events
            WHERE fk_cases = ? AND event_description = ? AND event_date = ?
        """, (fk_case, description, event_date))
        if cursor.fetchone()[0] == 0:
            cursor.execute("""
                INSERT INTO docketwatch.dbo.case_events (
                    fk_cases, event_date, event_description,
                    additional_information, fk_task_run_log
                )
                VALUES (?, ?, ?, ?, ?)
            """, (fk_case, event_date, description, extra, fk_task_run))
            inserted += 1
    cursor.connection.commit()
    log_type = "ALERT" if inserted > 0 else "INFO"
    log_message(cursor, fk_task_run, log_type, f"Inserted {inserted} new event(s) for case ID {fk_case}", fk_case=fk_case)
    return inserted

def extract_case_name_from_html(page_source, case_name_selector=None):
    try:
        if not case_name_selector:
            return None  # skip if selector is not set
        soup = BeautifulSoup(page_source, "html.parser")
        element = soup.select_one(case_name_selector)
        if element:
            return element.get_text(strip=True)
        else:
            logging.info(f"Case name element not found using selector: {case_name_selector}")
    except Exception as e:
        logging.warning(f"Failed to extract case name using selector '{case_name_selector}': {e}")
    return None  # fallback if not found or error

def extract_court_and_type(soup, fk_county, cursor):
    import logging
    court_name = ""
    case_type = ""
    fk_court = None

    court_span = soup.find("span", {"id": "liCRCourtLocation"}) or soup.find("span", {"id": "liCourtLocationNotCR"})
    if court_span:
        court_name = court_span.get_text(strip=True)
        cursor.execute("""
            SELECT court_code FROM docketwatch.dbo.courts
            WHERE fk_county = ? AND court_name = ?
        """, (fk_county, court_name))
        result = cursor.fetchone()
        if result:
            fk_court = result[0]
        else:
            logging.warning(f"[NO MATCH] Court not found in DB: '{court_name}' (fk_county: {fk_county}) — skipping insert.")

    type_span = soup.find("span", {"id": "liCaseType"})
    if type_span:
        case_type = type_span.get_text(strip=True)

    return fk_court, case_type


def perform_tool_login(driver, context):
    log_message(None, context["fk_task_run"], "INFO", f"Performing login for tool {context['tool_id']}")

    try:
        driver.get(context["login_url"])

        # Wait for and fill in username
        username_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, context["username_selector"]))
        )
        username_input.clear()
        username_input.send_keys(context["username"])

        # Wait for and fill in password
        password_input = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, context["password_selector"]))
        )
        password_input.clear()
        password_input.send_keys(context["pass"])

        # Click TOS checkbox if required
        if context.get("login_checkbox"):
            try:
                checkbox = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, context["login_checkbox"]))
                )
                if not checkbox.is_selected():
                    checkbox.click()
                log_message(None, context["fk_task_run"], "INFO", "TOS checkbox clicked.")
                time.sleep(0.5)
            except Exception as e:
                log_message(None, context["fk_task_run"], "WARNING", f"Failed to click TOS checkbox: {e}")

        # Wait for and click the login button
        WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, context["login_button_selector"]))
        ).click()

        log_message(None, context["fk_task_run"], "INFO", "Login attempt completed.")
        time.sleep(3)

    except Exception as e:
        log_message(None, context["fk_task_run"], "ERROR", f"Login failed: {e}")
        raise

def get_tool_selectors(cursor, tool_id):
    cursor.execute("""
        SELECT 
            search_url,
            case_number_input,
            search_button_selector,
            result_row_selector,
            case_link_selector,
            case_name_selector,
            court_name_selector,
            case_type_selector,
            events_table_selector,
            event_col_0_label,
            event_col_1_label,
            event_col_2_label,
            events_column_count,
            pre_search_click_selector,
            captcha_type,
            fk_county
        FROM docketwatch.dbo.tools
        WHERE id = ?
    """, (tool_id,))
    row = cursor.fetchone()
    if not row:
        return {}

    keys = [desc[0] for desc in cursor.description]
    return dict(zip(keys, row))

# === Common Utility: Solve 2Captcha reCAPTCHA ===

def solve_recaptcha_2captcha(api_key, site_key, page_url):
    import requests
    import time

    logging.info("Sending CAPTCHA to 2Captcha...")

    payload = {
        'key': api_key,
        'method': 'userrecaptcha',
        'googlekey': site_key,
        'pageurl': page_url,
        'json': 1
    }
    response = requests.post("http://2captcha.com/in.php", data=payload).json()
    if response.get("status") != 1:
        logging.error("2Captcha request failed: " + response.get("request", ""))
        raise Exception("2Captcha request failed: " + response.get("request", ""))

    captcha_id = response["request"]
    logging.info(f"2Captcha request accepted. ID: {captcha_id}")

    for attempt in range(20):
        time.sleep(3)
        check = requests.get(f"http://2captcha.com/res.php?key={api_key}&action=get&id={captcha_id}&json=1").json()
        if check.get("status") == 1:
            logging.info("CAPTCHA solution received.")
            return check["request"]
        logging.info(f"Waiting for CAPTCHA solution... attempt {attempt + 1}")

    logging.error("2Captcha timeout waiting for solution")
    raise Exception("2Captcha timeout waiting for solution")

# === PACER Billing Extraction (Current Table Format) ===

def extract_and_store_pacer_billing(soup, cursor, fk_case, fk_task_run=None):
    try:
        billing_table = None
        for table in soup.find_all("table"):
            # Find table with "PACER Service Center" in header
            if table.find("font", string=re.compile("PACER Service Center")):
                billing_table = table
                break

        if not billing_table:
            log_message(cursor, fk_task_run, "INFO", "No PACER billing table found.")
            return False

        rows = billing_table.find_all("tr")
        data = {}
        billing_reference = None

        # Parse the transaction date/time
        for row in rows:
            if row.find("font", color="DARKBLUE") and row.find("td", align="CENTER"):
                date_font = row.find("font", color="DARKBLUE")
                billing_reference = date_font.get_text(strip=True)
                log_message(cursor, fk_task_run, "INFO", f"Billing reference (datetime): {billing_reference}")

        # Now parse all data in <th>/<td> pairs (across and down)
        for row in rows:
            cells = row.find_all(['th', 'td'])
            i = 0
            while i < len(cells) - 1:
                label = cells[i].get_text(strip=True).replace(":", "")
                value = cells[i+1].get_text(strip=True)
                if label:
                    data[label] = value
                    log_message(cursor, fk_task_run, "DEBUG", f"Parsed billing data: {label} = {value}")
                i += 2

        # log_message(cursor, fk_task_run, "DEBUG", f"Parsed billing data dictionary: {data}")

        pages = int(data.get("Billable Pages", "0") or "0")
        cost = float((data.get("Cost", "0.00") or "0.00").replace('$', '').replace(',', ''))
        description = data.get("Description", None)
        pacer_login = data.get("PACER Login", None)
        client_code = data.get("Client Code", "DocketWatch")
        search_criteria = data.get("Search Criteria", None)

        cursor.execute("""
            INSERT INTO docketwatch.dbo.pacer_billing_history (
                fk_case, created_at, billing_reference, pages, cost, 
                description, pacer_login, client_code, search_criteria
            )
            VALUES (?, GETDATE(), ?, ?, ?, ?, ?, ?, ?)
        """, (
            fk_case, billing_reference, pages, cost,
            description, pacer_login, client_code, search_criteria
        ))
        cursor.connection.commit()

        log_message(cursor, fk_task_run, "INFO", f"PACER billing: {pages} pages / ${cost:.2f} – {description}")
        return True

    except Exception as e:
        log_message(cursor, fk_task_run, "ERROR", f"Failed to extract PACER billing data: {e}")
        return False
