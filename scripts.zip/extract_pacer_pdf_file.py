import sys
import argparse
import pyodbc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
import traceback
import urllib.request
import shutil
import zipfile
from urllib.parse import urlencode

from scraper_base import log_message, setup_logging, get_db_cursor, get_task_context_by_tool_id

CHROMEDRIVER_PATH = "C:/WebDriver/chromedriver.exe"
LOG_FILE = r"u:/tmztools/python/logs/extract_pacer_pdf_file.log"
FINAL_PDF_DIR = r"\\10.146.176.84\general\mediaroot\pacer_pdfs"
setup_logging(LOG_FILE)

def main():
    parser = argparse.ArgumentParser(description="Download each PACER PDF directly and update status.")
    parser.add_argument("case_event_id", type=str, help="GUID of the case_events record")
    args = parser.parse_args()

    try:
        script_filename = os.path.splitext(os.path.basename(__file__))[0]
        setup_logging(f"u:/tmztools/python/logs/{script_filename}.log")

        conn, cursor = get_db_cursor()
        context = get_task_context_by_tool_id(cursor, 2)
        fk_task_run = context["fk_task_run"] if context else None

        cursor.execute("""
        SELECT 
        c.pacer_id AS case_id,
        LEFT(e.event_url, CHARINDEX('.gov', e.event_url) + 3) AS base_url,
        e.event_description,
        e.event_url,
        e.arr_de_seq_nums,
        p.id AS case_events_pdf_id,
        ps.url,
        p.pacer_doc_id,
        RIGHT(CAST(p.pacer_doc_id AS VARCHAR), 8) AS pacer_doc_id_str,
        p.pdf_type,
        ps.url + '/cgi-bin/show_multidocs.pl?caseid=' + 
        CAST(c.pacer_id AS VARCHAR) +
        '&arr_de_seq_nums=' + 
        CAST(e.arr_de_seq_nums AS VARCHAR) +
        '&pdf_header=2&pdf_toggle_possible=1' +
        CASE 
            WHEN EXISTS (
                SELECT 1 
                FROM docketwatch.dbo.case_events_pdf p2 
                WHERE p2.fk_case_event = e.id 
                AND p2.pacer_doc_id <> p.pacer_doc_id
            )
            THEN '&exclude_attachments=' + ISNULL((
                STUFF((
                    SELECT ',' + RIGHT(CAST(p2.pacer_doc_id AS VARCHAR), 8)
                    FROM docketwatch.dbo.case_events_pdf p2
                    WHERE p2.fk_case_event = e.id 
                    AND p2.pacer_doc_id <> p.pacer_doc_id
                    FOR XML PATH(''), TYPE
                ).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
            ), '')
            ELSE ''
        END +
        '&zipit=1' AS download_url

        FROM docketwatch.dbo.case_events e
        INNER JOIN docketwatch.dbo.cases c ON c.id = e.fk_cases
        INNER JOIN docketwatch.dbo.pacer_sites ps ON ps.id = c.fk_pacer_site
        INNER JOIN docketwatch.dbo.case_events_pdf p ON p.fk_case_event = e.id
        WHERE e.id = ?
        AND p.isdownloaded = 0
        """, (args.case_event_id,))
        rows = cursor.fetchall()
        if not rows:
            log_message(cursor, fk_task_run, "INFO", "No PDFs pending download.")
            return

        opts = Options()
        opts.add_argument("--headless=new")  
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        prefs = {
            "download.default_directory": FINAL_PDF_DIR,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True,
            "profile.default_content_setting_values.automatic_downloads": 1
        }
        opts.add_experimental_option("prefs", prefs)
        service = Service(CHROMEDRIVER_PATH)
        driver = webdriver.Chrome(service=service, options=opts)
        wait = WebDriverWait(driver, 15)

        cursor.execute("SELECT username, pass, login_url FROM dbo.tools WHERE id = 2")
        row = cursor.fetchone()
        if not row:
            log_message(cursor, fk_task_run, "ERROR", "PACER credentials not found in DB (tools.id=2).")
            return
        USERNAME, PASSWORD, LOGIN_URL = row

        driver.get(LOGIN_URL)
        wait.until(EC.presence_of_element_located((By.NAME, "loginForm:loginName"))).send_keys(USERNAME)
        driver.find_element(By.NAME, "loginForm:password").send_keys(PASSWORD)
        try:
            driver.find_element(By.NAME, "loginForm:clientCode").send_keys("DocketWatch")
        except:
            pass
        driver.find_element(By.NAME, "loginForm:fbtnLogin").click()
        time.sleep(3)

        for row in rows:
            pdf_id = row.case_events_pdf_id
            download_url = row.download_url
            pacer_doc_id_str = row.pacer_doc_id_str
            pdf_type = row.pdf_type
            filename = f"{row.pacer_doc_id}.pdf"
            dest_path = os.path.join(FINAL_PDF_DIR, filename)
            try:
                driver.get(download_url)
                time.sleep(2)

                if "Warning:" in driver.page_source and "referrer_form" in driver.page_source:
                    form = driver.find_element(By.ID, "referrer_form")
                    driver.execute_script("arguments[0].submit();", form)
                    time.sleep(3)

                try:
                    download_button = driver.find_element(By.XPATH, "//input[@type='button' and @value='Download Documents']")
                    driver.execute_script("arguments[0].click();", download_button)
                    time.sleep(3)
                except:
                    log_message(cursor, fk_task_run, "WARNING", f"Download Documents button not found for {filename}")

                # Wait for ZIP file
                zip_file = None
                start_time = time.time()
                while time.time() - start_time < 30:
                    zips = [f for f in os.listdir(FINAL_PDF_DIR) if f.endswith(".zip")]
                    if zips:
                        latest = max([os.path.join(FINAL_PDF_DIR, f) for f in zips], key=os.path.getctime)
                        if not os.path.exists(latest + ".crdownload"):
                            zip_file = latest
                            break
                    time.sleep(1)

                if zip_file:
                    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                        zip_ref.extractall(FINAL_PDF_DIR)
                        for name in zip_ref.namelist():
                            extracted_pdf = os.path.join(FINAL_PDF_DIR, name)
                            new_name = f"{row.pacer_doc_id}.pdf"
                            new_path = os.path.join(FINAL_PDF_DIR, new_name)
                            if os.path.exists(extracted_pdf):
                                os.rename(extracted_pdf, new_path)
                                cursor.execute("""
                                    UPDATE docketwatch.dbo.case_events_pdf
                                    SET isDownloaded = 1, local_pdf_filename = ?
                                    WHERE id = ?
                                """, (new_name, pdf_id))
                                conn.commit()
                                log_message(cursor, fk_task_run, "INFO", f"Downloaded, renamed and extracted: {new_name}")
                    os.remove(zip_file)
                else:
                    log_message(cursor, fk_task_run, "WARNING", f"ZIP file not found after wait for {filename}")

            except Exception as ex:
                log_message(cursor, fk_task_run, "ERROR", f"Error downloading {download_url}: {ex}")

    except Exception as e:
        log_message(cursor, fk_task_run, "ERROR", f"Exception occurred: {str(e)}")
        traceback.print_exc()
    finally:
        if 'driver' in locals() and driver:
            driver.quit()
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    main()
