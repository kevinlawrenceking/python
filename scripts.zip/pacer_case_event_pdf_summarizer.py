"""
pacer_case_event_pdf_summarizer.py   (2025-06  •  unified-docs edition)
----------------------------------------------------------------------
1. For a given case_events_pdf row, find the LATEST PDF in docketwatch.dbo.documents
2. Extract text: PyPDF2 → Tesseract → PaddleOCR fallback
3. Save raw + cleaned OCR into documents and case_events_pdf.ocr_text
4. Build Gemini 1.5-flash prompt, store summary + HTML back to case_events_pdf
"""

import os, re, json, traceback, cv2, numpy as np
from datetime import datetime

import pyodbc, PyPDF2, pytesseract, requests, markdown2
from pdf2image import convert_from_path
from paddleocr import PaddleOCR
from bs4 import BeautifulSoup
from cleantext import clean as clean_unicode
from scraper_base import log_message

# ============ LOCAL CONFIG ==============
DSN              = "Docketwatch"   # ODBC DSN
POPPLER_PATH     = r"C:\Poppler\bin"
TESSERACT_PATH   = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
MODEL_NAME       = "gemini-1.5-flash"
MAX_PROMPT_CHARS = 12_000
pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

# PaddleOCR init once
paddle_ocr = PaddleOCR(use_angle_cls=True, lang='en')

# ========= DB helpers =========
def get_cursor():
    conn = pyodbc.connect(f"DSN={DSN};TrustServerCertificate=yes;")
    conn.setdecoding(pyodbc.SQL_WCHAR, encoding="utf-8")
    conn.setencoding(encoding="utf-8")
    return conn, conn.cursor()

def get_util(cur, col):
    cur.execute(f"SELECT {col} FROM docketwatch.dbo.utilities")
    row = cur.fetchone()
    return row[0] if row else None

# ========= image pre-processing =========
def preprocess(img_bgr):
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 5, 75, 75)
    _, bw = cv2.threshold(gray, 0, 255,
                          cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    coords = np.column_stack(np.where(bw > 0))
    if coords.size == 0:
        return bw
    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    M = cv2.getRotationMatrix2D((bw.shape[1] / 2, bw.shape[0] / 2), angle, 1.0)
    bw = cv2.warpAffine(bw, M, (bw.shape[1], bw.shape[0]),
                        flags=cv2.INTER_CUBIC,
                        borderMode=cv2.BORDER_REPLICATE)
    return bw

# ========= OCR =========
def tesseract_page(img):
    txt = pytesseract.image_to_string(img, config="--oem 1 --psm 6")
    data = pytesseract.image_to_data(img,
                                     output_type=pytesseract.Output.DICT)
    conf = np.mean([int(c) for c in data["conf"] if int(c) > -1]) \
           if data["text"] else 0
    return txt, conf

def paddle_page(img):
    result = paddle_ocr.ocr(img)[0]
    return " ".join([seg[1][0] for seg in result])

def pdf_to_text(path):
    text = ""
    try:
        with open(path, "rb") as f:              # 1) direct extraction
            reader = PyPDF2.PdfReader(f)
            for pg in reader.pages:
                text += (pg.extract_text() or "") + "\n"
    except Exception:
        pass

    if len(text.strip()) >= 200:
        return text

    pages = convert_from_path(path, dpi=300, poppler_path=POPPLER_PATH)
    for pil in pages:                            # 2) image OCR
        img = preprocess(cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR))
        tess_txt, conf = tesseract_page(img)
        if conf < 80:
            tess_txt = paddle_page(img)
        text += tess_txt + "\n"
    return text

# ========= cleaning =========
def clean_ocr_text(txt):
    txt = re.sub(r'^Page \d+\s*\n', '', txt, flags=re.MULTILINE)
    txt = re.sub(r'-\n(?=\w)', '', txt)                     # de-hyphenate
    txt = re.sub(r'(?<!\n)\n(?!\n)', ' ', txt)             # unwrap lines
    txt = re.sub(r' +', ' ', txt)
    txt = txt.replace('–', '-')
    txt = clean_unicode(txt, fix_unicode=True)
    return txt.strip()

# ========= Gemini prompt =========
RULES = r"""
SYSTEM: You are an experienced legal journalist writing for TMZ DocketWatch.
Audience: general-interest readers. Tone: plain English, neutral, no speculation.

### FORMAT RULES (MUST follow exactly)
### EVENT SUMMARY
<≤150-word summary>
### NEWSWORTHINESS
Yes – one ≤15-word reason   (or “No – …”)
### STORY
HEADLINE: <≤15-word Title Case headline or ‘No story necessary.’>
SUBHED:   <≤25-word subhed or ''>

<body markdown 250–400 words with <h3> heads (Key Details, What’s Next)>

**DO NOT MENTION CASE STATUS**

--- PDF BEGINS ---
{PDF_BODY}
--- PDF ENDS ---
Begin.
"""

def ask_gemini(case_summary, event_desc, event_date, pdf_text, api_key):
    header = f"""
<CASE_OVERVIEW>
{case_summary}
</CASE_OVERVIEW>

<EVENT>
date: {event_date}
description: {event_desc}
</EVENT>
"""
    if len(pdf_text) > 10_000:
        pdf_text = pdf_text[:8000] + "\n…\n" + pdf_text[-2000:]

    prompt = RULES.replace("{PDF_BODY}", header + pdf_text)[:MAX_PROMPT_CHARS]
    body = {
        "contents":[{"role":"user","parts":[{"text":prompt}]}],
        "generationConfig":{"temperature":0.4,"maxOutputTokens":1000}
    }
    r = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL_NAME}:generateContent?key={api_key}",
        headers={"Content-Type":"application/json"},
        data=json.dumps(body), timeout=90)
    r.raise_for_status()
    return r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()

# ========= main =========
def process_single_pdf(doc_uid: str):
    conn, cur = get_cursor()
    key       = get_util(cur, "gemini_api")
    docs_root = get_util(cur, "docs_root")
    if not (key and docs_root):
        print("Missing Gemini key or docs_root."); return

    # 1. pull event + case id
    cur.execute("""
        SELECT c.summarize,
               e.event_description,
               CONVERT(char(10), e.event_date, 23),
               p.ocr_text,
               e.fk_cases
        FROM   docketwatch.dbo.documents p
        JOIN   docketwatch.dbo.case_events     e ON e.id = p.fk_case_event
        JOIN   docketwatch.dbo.cases           c ON c.id = e.fk_cases
        WHERE  p.doc_uid = ?
    """, doc_uid)
    row = cur.fetchone()
    if not row:
        print("PDF id not found."); return

    summ, ev_desc, ev_date, ocr_text, case_id = row

    # 2. newest PDF from unified documents
    cur.execute("""
        SELECT TOP 1 rel_path
        FROM   docketwatch.dbo.documents
        WHERE  fk_case = ?
        ORDER  BY date_downloaded DESC
    """, case_id)
    rel_row = cur.fetchone()
    abs_path = os.path.join(docs_root, rel_row[0]) if rel_row else None

    # 3. OCR if ocr_text weak
    if (not ocr_text or len(ocr_text.strip()) < 100) and abs_path and os.path.isfile(abs_path):
        print("OCR →", abs_path)
        raw   = pdf_to_text(abs_path)
        clean = clean_ocr_text(raw)

        # store OCR text in documents
        cur.execute("""
            UPDATE docketwatch.dbo.documents
               SET ocr_text_raw = ?, ocr_text = ?
            WHERE id = CAST(? AS uniqueidentifier)
            """, (raw, clean, doc_uid))

        conn.commit()
        ocr_text = clean
        print("ocr_text populated.")

    pdf_text = clean_ocr_text(ocr_text or "")

    # 4. Gemini summarization
    try:
        gem = ask_gemini(summ or "", ev_desc or "", ev_date or "", pdf_text, key)
    except Exception as e:
        print("Gemini error:", e)
        log_message(cur, None, "ERROR", f"Gemini fail {doc_uid}: {e}")
        return

    html = BeautifulSoup(markdown2.markdown(gem), "html.parser").prettify()

    cur.execute("""
        UPDATE docketwatch.dbo.documents
           SET summary_ai     = ?,
               summary_ai_html = ?,
               ai_processed_at = ?
         WHERE id = CAST(? AS uniqueidentifier)
    """, gem, html, datetime.now(), doc_uid)
    conn.commit()
    print("Update successful.")
    log_message(cur, None, "INFO", f"PDF {doc_uid} processed")

    cur.close(); conn.close()

# -------------------------------------------------
if __name__ == "__main__":
    # example GUID; replace with any p.id you need
    process_single_pdf("7A3A340A-88B9-49FD-B8DB-B5DCBD6BF157")
