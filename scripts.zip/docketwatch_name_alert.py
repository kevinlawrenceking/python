import time
import pyodbc
import re
import os
import sys
import logging
import psutil
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime

# ** Configure Logging **
LOG_FILE = r"\\10.146.176.84\general\tmztools\python\logs\docketwatch_name_alert.log"
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# ** Extract script filename without extension **
script_filename = os.path.splitext(os.path.basename(__file__))[0]  # e.g., 'docketwatch_name_alert'

# ** Database Connection **
try:
    conn = pyodbc.connect("DSN=Docketwatch;TrustServerCertificate=yes;")
    cursor = conn.cursor()
    logging.info("Database Connection Established")
except Exception as e:
    logging.error(f"Database Connection Failed: {str(e)}")
    sys.exit(1)

# ** Fetch Task Run ID **
query = """
    SELECT TOP 1 r.id as fk_task_run 
    FROM docketwatch.dbo.task_runs r
    INNER JOIN docketwatch.dbo.scheduled_task s ON r.fk_scheduled_task = s.id 
    WHERE s.filename = ? 
    ORDER BY r.id DESC
"""
cursor.execute(query, (script_filename,))
task_run = cursor.fetchone()

# ** Set fk_task_run **
fk_task_run = task_run[0] if task_run else None

# ** Logging Function **
def log_message(log_type, message):
    """Logs to both the log file and the database and returns log ID."""
    logging.info(message)

    if fk_task_run:
        try:
            insert_log_query = """
                INSERT INTO docketwatch.dbo.task_runs_log (fk_task_run, log_timestamp, log_type, description)
                OUTPUT INSERTED.id
                VALUES (?, GETDATE(), ?, ?)
            """
            cursor.execute(insert_log_query, (fk_task_run, log_type, message))
            log_id = cursor.fetchone()[0]
            conn.commit()
            return log_id
        except pyodbc.Error as e:
            print(f"Database Logging Error: {str(e)}")
            return None

log_message("INFO", "=== Search for Michelle Trachtenberg cases started ===")

try:
    # ** Start ChromeDriver **
    CHROMEDRIVER_PATH = "C:/WebDriver/chromedriver.exe"
    chrome_options = Options()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")

    service = Service(CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    log_message("INFO", "ChromeDriver Initialized Successfully")

    # ** Fetch Username & Password from Database **
    try:
        cursor.execute("SELECT nyc_user, nyc_pwd FROM docketwatch.dbo.utilities WHERE id=1")
        credentials = cursor.fetchone()
        
        if not credentials:
            log_message("ERROR", "No credentials found in database. Exiting...")
            driver.quit()
            conn.close()
            sys.exit()
        
        nyc_username, nyc_password = credentials
        log_message("INFO", "Retrieved login credentials from database.")

    except Exception as e:
        log_message("ERROR", f"Error fetching credentials: {str(e)}")
        driver.quit()
        conn.close()
        sys.exit()

    # ** Login to NYSCEF **
    LOGIN_URL = "https://iapps.courts.state.ny.us/nyscef/Login"
    driver.get(LOGIN_URL)
    time.sleep(5)

    try:
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "txtUserName"))).send_keys(nyc_username)
        time.sleep(2)
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "pwPassword"))).send_keys(nyc_password)
        time.sleep(2)
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "btnLogin"))).click()
        time.sleep(5)
        log_message("INFO", "Logged in successfully.")

    except Exception as e:
        log_message("ERROR", f"Failed to log in: {str(e)}")
        driver.quit()
        sys.exit()

    # ** Navigate to Surrogate's Court File Search Page **
    SEARCH_URL = "https://iapps.courts.state.ny.us/nyscef/SurrogatesFileRecordSearch"
    driver.get(SEARCH_URL)
    time.sleep(5)

    # ** Select Court - Westchester County Surrogate's Court **
    try:
        court_value = "lvbt9e9D8n4m0vSXdSUing=="  
        court_select = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "selCourt")))
        driver.execute_script(f"arguments[0].value = '{court_value}';", court_select)
        time.sleep(2)
        driver.execute_script("arguments[0].dispatchEvent(new Event('change'));", court_select)
        log_message("INFO", "Successfully selected NYC Surrogate Court.")

    except Exception as e:
        log_message("ERROR", f"Failed to select court dropdown: {str(e)}")
        driver.quit()
        sys.exit()

    # ** Enter Party Name - Michelle Trachtenberg **
    try:
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.NAME, "txtFirstName"))).send_keys("Michelle")
        time.sleep(2)
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.NAME, "txtLastName"))).send_keys("Trachtenberg")
        time.sleep(2)
        log_message("INFO", "Entered name: Michelle Trachtenberg")

    except Exception as e:
        log_message("ERROR", f"Failed to enter name: {str(e)}")
        driver.quit()
        sys.exit()

    # ** Click "Search" Button **
    try:
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.NAME, "btnSearch"))).click()
        time.sleep(5)
        log_message("INFO", "Search executed successfully.")

    except Exception as e:
        log_message("ERROR", f"Failed to click 'Search' button: {str(e)}")
        driver.quit()
        sys.exit()

    # ** Check if File Records Were Found **
    try:
        no_records = driver.find_elements(By.XPATH, "//td[contains(text(), 'No File Records Found')]")
        if no_records:
            log_message("INFO", "No cases for Michelle Trachtenberg found.")
        else:
            file_rows = driver.find_elements(By.XPATH, "//table[@class='dataList']/tbody/tr")
            for row in file_rows:
                columns = row.find_elements(By.TAG_NAME, "td")
                if len(columns) < 4:
                    continue
                
                file_no, file_name, dob_dod, address = columns[0].text.strip(), columns[1].text.strip(), columns[2].text.strip(), columns[3].text.strip()

                cursor.execute("""
                    INSERT INTO docketwatch.dbo.records_tmp (file_no, file_name, dob_dod, address)
                    SELECT ?, ?, ?, ?
                    WHERE NOT EXISTS (SELECT 1 FROM docketwatch.dbo.records_tmp WHERE file_no = ?)
                """, (file_no, file_name, dob_dod, address, file_no))
                conn.commit()
                log_message("INFO", "Case for Michelle Trachtenberg discovered!")

    except Exception as e:
        log_message("ERROR", f"Error processing search results: {str(e)}")

finally:
    cursor.close()
    conn.close()
    driver.quit()
    log_message("INFO", "Westchester Surrogate's Court File Search Completed Successfully!")
