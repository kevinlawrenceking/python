import pyodbc
import subprocess
import time

# Database connection
conn = pyodbc.connect("DSN=Docketwatch;TrustServerCertificate=yes;")
cursor = conn.cursor()

# Query to find applicable case_event IDs
cursor.execute("""
    SELECT id AS case_id 
    FROM case_events 
    WHERE event_url IS NOT NULL 
      AND id NOT IN (
        SELECT DISTINCT fk_case_event FROM docketwatch.dbo.case_events_pdf
      ) 
      AND fk_cases IN (
        SELECT id FROM cases WHERE fk_priority = 4
      ) 
    ORDER BY created_at DESC
""")

case_ids = [row.case_id for row in cursor.fetchall()]

print(f"Found {len(case_ids)} case_events to process.")

for case_id in case_ids:
    print(f"Running for case_event ID: {case_id}")
    try:
        subprocess.run(["python", "u:\\tmztools\\python\\extract_pacer_pdf_metadata.py", str(case_id)], check=True)
        time.sleep(2)  # slight delay to avoid overloading system
    except subprocess.CalledProcessError as e:
        print(f"Error running extract_pacer_pdf_metadata.py for case_id {case_id}: {e}")

cursor.close()
conn.close()
