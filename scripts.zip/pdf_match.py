import os
import pyodbc

FINAL_PDF_DIR = r"\\10.146.176.84\general\mediaroot\pacer_pdfs"

# --- Connect to DB ---
conn = pyodbc.connect("DSN=Docketwatch;TrustServerCertificate=yes;")
cursor = conn.cursor()

# --- Get all local_pdf_filename values from DB ---
cursor.execute("""
    SELECT local_pdf_filename
    FROM docketwatch.dbo.case_events_pdf
    WHERE isDownloaded = 1 AND local_pdf_filename IS NOT NULL AND LEN(local_pdf_filename) > 0
""")
db_files = set(row.local_pdf_filename.strip() for row in cursor.fetchall())

# --- Get all files in directory ---
disk_files = set(f for f in os.listdir(FINAL_PDF_DIR) if f.lower().endswith(".pdf"))

# --- Compare ---
missing_on_disk = db_files - disk_files
extra_on_disk = disk_files - db_files

print("\n=== Validation Report ===\n")
print(f"✔ Files expected in DB (isDownloaded=1): {len(db_files)}")
print(f"✔ Files found on disk: {len(disk_files)}\n")

if missing_on_disk:
    print(f"❌ Missing on Disk ({len(missing_on_disk)}):")
    for f in sorted(missing_on_disk):
        print(f"  - {f}")
else:
    print("✅ All expected files from DB are present on disk.")

if extra_on_disk:
    print(f"\n⚠ Extra on Disk ({len(extra_on_disk)}):")
    for f in sorted(extra_on_disk):
        print(f"  - {f}")
else:
    print("\n✅ No extra files on disk.")

# Cleanup
cursor.close()
conn.close()
